#pragma once
float division(float a, float b);
int resta(int a, int b);
int suma(int a, int b);
int multiplicacion(int a, int b);
