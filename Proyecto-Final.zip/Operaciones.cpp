#include <stdio.h>

float division(float a, float b)
{
  return (a/b);
}

int resta(int a, int b)
{
return (a-b);
}

int suma(int a, int b)
{
return (a+b);
}

int multiplicacion(int a, int b)
{
return (a*b);
}


